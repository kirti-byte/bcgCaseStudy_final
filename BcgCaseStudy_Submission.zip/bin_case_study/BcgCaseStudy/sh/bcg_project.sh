kinit -kt /home/users/dscmbtch/dscmbtch.keytab dscmbtch

#!/bin/bash


export inputData="test/bcg"

export outputData="output/bcg"

/usr/hdp/2.6.4.0-91/spark2/bin/spark-submit --class BcgCaseStudy --master yarn /grid/0/bin_case_study/BcgCaseStudy/bcgcasestudy_2.11-1.0.jar $inputData $outputData

status=$?

echo $status

if [ $status -eq 0 ]
then
	echo "Job completed Successfully!"
else
	echo "Job Failed!"
	exit 1
fi

hadoop fs -get output/bcg /grid/0/bin_case_study/output_data/
status=$?
echo $status

if [ $status -eq 0 ]
then
	echo "Files transferred Successfully!"
else
	echo "Files are already present at destination location."
	exit 1
fi
